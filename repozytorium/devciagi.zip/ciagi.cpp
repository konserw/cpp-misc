/*
 * podci�gi
 *
 * Copyright (C) 2009 Kamil Strzempowicz
 * Niniejszy program jest wolnym oprogramowaniem; mo�esz go 
 * rozprowadza� dalej i/lub modyfikowa� na warunkach Powszechnej
 * Licencji Publicznej GNU, wydanej przez Fundacj� Wolnego
 * Oprogramowania - wed�ug wersji 2-giej tej Licencji lub kt�rej�
 * z p�niejszych wersji. 
 * Niniejszy program rozpowszechniany jest z nadziej�, i� b�dzie on 
 * u�yteczny - jednak BEZ JAKIEJKOLWIEK GWARANCJI, nawet domy�lnej 
 * gwarancji PRZYDATNO�CI HANDLOWEJ albo PRZYDATNO�CI DO OKRE�LONYCH 
 * ZASTOSOWA�. W celu uzyskania bli�szych informacji - Powszechna 
 * Licencja Publiczna GNU. 
 * Z pewno�ci� wraz z niniejszym programem otrzyma�e� te� egzemplarz 
 * Powszechnej Licencji Publicznej GNU (GNU General Public License);
 * je�li nie - napisz do Free Software Foundation, Inc., 675 Mass Ave,
 * Cambridge, MA 02139, USA.
 * 
 * Pozdrawiam, konserw.
 * konserw@gmail.com
 */

#include "PCH.h"
#include "header.h"

int main() 
{ 
	int *t;
	int start, koniec, n;
	bool flaga = false;
	std::vector<podciag> ciagi;

	srand(static_cast<unsigned>(time(NULL))); 

	std::cout<<"Podaj rozmiar tablicy:\t";
	std::cin>>n;
	t = new int [n];

	for(int i=0; i < n; i++){ 
		t[i]=rand()%2; 
		std::cout<<t[i]<<"; ";
	}
	for(int i=0; i < n; ++i){
		if(t[i] == 0 && flaga == false){
		   start = i;
		   flaga = true;
		}
	   else if(t[i] == 1 && flaga == true){
		   koniec = i - 1; //ostatnie zero przed jedynka
		   flaga = false;
		   podciag nowy(start, koniec);
		   ciagi.push_back(nowy);
	   }
	}
	if(ciagi.size() > 0){
	   int najwiekszy=0;
	   for(unsigned i=1; i < ciagi.size(); ++i){ //od jedynki bo zerowego nie musimy sprawdzac
		   if(ciagi[i].ile > ciagi[najwiekszy].ile)
			   najwiekszy = i;
	   }
	   std::cout<<"\n"
		   "Najdluzszy podciag zer zaczyna sie w indekcie "<<ciagi[najwiekszy].start<<",\n"
		   "Ma dlugosc "<<ciagi[najwiekszy].ile<<"\n"
		   "I konczy sie w indeksie "<<ciagi[najwiekszy].koniec<<"\n";

	}
	else std::cout<<"Nie istnieje zaden podciag zer\n";
	std::cin.ignore();
	std::cin.get();
	delete [ ] t;
	return 0; 
}