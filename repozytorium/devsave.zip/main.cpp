#include "stdafx.h"

int main(){
	std::string path, linie;
	init(25, 80);

	short x=4, y=6;
	border();

	if(!(sciezka(path))){
		log("main", "sciezka error");
		error();
		return 0;
	}

	wybor_moda(path);

	if(!(wybor_save(path))){
		log("main", "wybor save error");
		error();
		return 0;
	}

	if(!(load(path, linie))){
		log("main", "load error");
		error();
		return 0;
	}

/*
###############################
###		W�a�ciwy edytor		###
###############################
*/	
	logline();
	log("main", "Pocz�tek w�a�ciwego edytora");
	historia(linie);
	log("main", "po historii");
	save(linie, path);
	log("main", "exiting");

	endwin();
	return 0;
}


