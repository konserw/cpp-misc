
#include "stdafx.h"

void historia(std::string& wejscie){

	log("historia", "poczatek historii");

	std::vector<std::string> buff;
	size_t pomoc, exit;
	std::string re;
	std::stringstream sstr;

	border();
	mvprintw(10, 30, "Usuwanie historii...");
	refresh();

	pomoc = wejscie.find("REB={");
	exit = wejscie.find("flags={", pomoc);
	
	buff.push_back("REB={");
	buff.push_back("history={");
	buff.push_back("aristocracy_plutocracy=0");
	buff.push_back("centralization_decentralization=0");
	buff.push_back("innovative_narrowminded=0");
	buff.push_back("mercantilism_freetrade=0");
	buff.push_back("imperialism_isolationism=0");
	buff.push_back("secularism_theocracy=0");
	buff.push_back("offensive_defensive=0");
	buff.push_back("land_naval=0");
	buff.push_back("quality_quantity=0");
	buff.push_back("serfdom_freesubjects=0");
	buff.push_back("technology_group=latin");
	buff.push_back("}\n}");

	for(unsigned i=0; i<buff.size(); ++i)
		sstr << buff[i] << "\n";
	re = sstr.str();
	wejscie.replace(pomoc, exit - pomoc, re);
	log("histroia", "zreplacowano");
}

bool load(const std::string& path, std::string& buff){

	std::ifstream plik(path.c_str()); 
	if(!(plik.good() && plik.is_open())){
		log("load", "otworzenie pliku nie powiodlo sie", path.c_str());
		return false;
	}

	logline();	
	log("load", "wczytywanie");

	loading();
	getline(plik, buff, '\0');
	log("load", "Wczytano znakow", buff.size());
	plik.close();

	border();
	mvprintw(2, 10, "Plik wczytany prawidlowo!");
	mvprintw(4, 10, "Wczytano %lu znakow", buff.size());
	cont();
	log("load", "Koniec loadu\n");
	return true;
}

bool sciezka(std::string& path){
	log("sciezka", "Pocz�tek szuaknia scie�ki");

	HKEY hkSoftware, hkParadox, hkEU;
	LONG result;
	char* buf;
	const int rozmiar_bufora = 500;
	DWORD dwBufSize = rozmiar_bufora;
	DWORD typ_klucza = REG_SZ; 

	if(RegOpenKeyExA(HKEY_LOCAL_MACHINE, "SOFTWARE", 0, KEY_ALL_ACCESS, &hkSoftware) == ERROR_SUCCESS)
		log("sciezka", "Udalo sie otworzyc klucz software.");
	else{
		log("sciezka", "nie uda�o si� otworzy� klucza software");
		return false;
	}	

	result = RegOpenKeyExA(hkSoftware, "Paradox Interactive", 0, KEY_ALL_ACCESS, &hkParadox);
	if(result == ERROR_SUCCESS)
		log("sciezka", "Udalo sie otworzyc klucz Paradox Interactive");
	else{
		log("sciezka", "ERROR! (mozliwe, ze masz niepoprawnie zainstaowana gre, badz nie masz jej wcale)");
		return false;
	}
	result = RegOpenKeyExA(hkParadox, "Europa Universalis III", 0, KEY_ALL_ACCESS, &hkEU);
	if(result == ERROR_SUCCESS)
		log("sciezka", "Udalo sie otworzyc klucz Europa Universalis III");
	else{
		log("sciezka", "ERROR! (mozliwe, ze masz niepoprawnie zainstaowana gre, badz nie masz jej wcale)");
		return false;
	}

	buf = new char [rozmiar_bufora + 1];

    result = RegQueryValueExA(hkEU, "app", NULL, &typ_klucza, (LPBYTE)buf, &dwBufSize);
	if(result == ERROR_SUCCESS){
		buf[rozmiar_bufora] = 0;
	}
	else if(result == ERROR_FILE_NOT_FOUND){
		log("sciezka", "nie odnaleziono wartosci - gra zostala nieprawidlowo zainstalowana");
		delete[] buf;
		return false;
	}
	else{
		log("sciezka", "unknown error");
		delete[] buf;
		return false;
	}
	path = buf;
	delete[] buf;
	size_t pos = path.find_last_of("\\");
	path = path.substr(0, ++pos);
	log("sciezka", "Sciezka instalacyjna gry", path.c_str());
	log("sciezka", "Koniec szukania scie�ki\n");
	return true;
}

void wybor_moda(std::string& path){
	log("wybor_moda", "Pocz�tek wyboru moda");


    WIN32_FIND_DATAA wfd; 
	std::vector<std::string> pliki;
	std::string jaki_mod;

	std::string buff = path;
	buff += "mod\\*"; 
	log("wybor_moda", "path + *", buff.c_str());
	pliki.push_back("vanila");
	HANDLE uchwyt = FindFirstFileA(buff.c_str(), &wfd); 
    if (uchwyt != INVALID_HANDLE_VALUE) 
    { 
		do{
			buff = static_cast<std::string>(wfd.cFileName);
			if(buff.find(".mod") != std::string::npos || buff.find(".MOD") != std::string::npos){
				pliki.push_back(buff.substr(0, buff.size()-4));
				log("wybor_moda", "znaleziono plik .mod", buff.c_str());
			}
		}while (FindNextFileA(uchwyt, &wfd)); 
        FindClose(uchwyt); 
    }
	if(pliki.size() == 1)jaki_mod = "vanila";
	else{
		std::vector<std::string> vOpis;
		vOpis.push_back("Witam w programie HistFree dla EU3");
		vOpis.push_back("Wybierz wersje gry z ktorej jest save:");
		
		cMenu menu(vOpis, pliki);

		menu.co(5, 5, jaki_mod);
		log("wybor_moda", "wybrana wersja gry", jaki_mod.c_str());

		if(jaki_mod != "vanila"){
			path += "mod\\";
			path += jaki_mod;
			path += "\\";
		}
		log("wybor_moda", "sciezka", path.c_str());
	}
	log("wybor_moda", "koniec wyboru moda");
}

bool wybor_save(std::string& path){

	logline();
	log("wybor_save", "Poczatek wybierania save");

    WIN32_FIND_DATAA wfd; 
	std::vector<std::string> pliki;
	path += "save games\\";

	std::string buff = path;
	buff += "*";
	log("wybor_save", "sciezka", buff.c_str());

	HANDLE uchwyt = FindFirstFileA(buff.c_str(), &wfd); 
    if (uchwyt != INVALID_HANDLE_VALUE) 
    { 
		do{
			buff = static_cast<std::string>(wfd.cFileName);
			if(buff.find(".eu3") != std::string::npos || buff.find(".EU3") != std::string::npos){
				pliki.push_back(buff);
				log("wybor_save", "znaleziono plik .eu3", buff.c_str());
			}
		}while (FindNextFileA(uchwyt, &wfd)); 
        FindClose(uchwyt); 
    }
	log("wybor_save", "znalezionych save'�w", pliki.size());
	if(pliki.size() == 0) return false;
	else{
		std::vector<std::string> vOpis;
		vOpis.push_back("Wybierz save do edycji:");
		
		cMenu menu(vOpis, pliki);
		menu.co(5, 5, buff);
		log("wybor_save", "wybrany save", buff.c_str());

		path += buff;
		log("wybor_save", "sciezka", path.c_str());
	}

	log("wybor_save", "Koniec wybierania save");
	return true;
}

void save(std::string& linie, std::string& path){

	WINDOW* wDol = stdscr;
	logline();
	log("save", "Poczatek zapisywania");

	std::vector<std::string> opis;
	opis.push_back("Nadpisac plik save?");
	std::vector<std::string> opcje;
	opcje.push_back("Nadpisz stary plik");
	opcje.push_back("Zapisz pod nazwa histfree.eu3");
	opcje.push_back("Nie zapisuj");
	cMenu nad(wDol, opis, opcje);
	short wybor = nad.wybor(10, 20);

	if(wybor == 1){
		path = path.substr(0, path.find_last_of('\\'));
		path += "\\histfree.eu3";
	}		
	if(wybor == 2) return;

	std::ofstream plik(path.c_str());
	if(!(plik.is_open() && plik.good())){
		log("save", "nie udalo sie otworzyc pliku");
		border(wDol);
		mvwprintw(wDol, 10, 10, "Nie udalo sie otworzyc pliku do zapisu");
		cont();
		return;
	}
	border(wDol);
	mvwprintw(wDol, 12, 25, "zapisywanie, prosze czekac...");
	wrefresh(wDol);
	plik << linie << /*std::endl <<*/ '\0';
	plik.close();
	log("save", "koniec zapisywania");
	border(wDol);
	mvwprintw(wDol, 10, 26, "Pomyslnie zapisano!");
	cont(wDol);
}
