#include <iostream>
#include <ctime>
#include <vector>
#include <algorithm>


using namespace std;

int main(){
    vector<int> liczby;
    int buff;
    
    srand(static_cast<unsigned int>(time(NULL)));
    
    cout<<"\tWylosowane liczby:\n";
    
    for(unsigned short i=0; i<100; ++i){
        buff=rand()%100;
        liczby.push_back(buff);
        cout<<buff<<", ";
        }
    cout<<"\nNacisnij dowolny klawisz aby posortowac";
    cin.get();
    sort(liczby.begin(), liczby.end());

    cout<<"\n\nPosortowane liczby:\n";
    for(unsigned short i=0; i<100; ++i)
                 cout<<liczby[i]<<", ";
     cout<<"\n\nNacisnij dowolny klawisz aby zakonczyc";
     cin.get();
    return 0;
}
