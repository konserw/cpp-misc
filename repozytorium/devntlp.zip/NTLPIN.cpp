/*
No Time Limit Patch 4 EU3:IN
Program s�u��cy do zmiany daty startu i ko�ca gry w EU3:IN

Copyright (C) 2009 Kamil Strzempowicz
Niniejszy program jest wolnym oprogramowaniem; mo�esz go 
rozprowadza� dalej i/lub modyfikowa� na warunkach Powszechnej
Licencji Publicznej GNU, wydanej przez Fundacj� Wolnego
Oprogramowania - wed�ug wersji 2-giej tej Licencji lub kt�rej�
z p�niejszych wersji. 
Niniejszy program rozpowszechniany jest z nadziej�, i� b�dzie on 
u�yteczny - jednak BEZ JAKIEJKOLWIEK GWARANCJI, nawet domy�lnej 
gwarancji PRZYDATNO�CI HANDLOWEJ albo PRZYDATNO�CI DO OKRE�LONYCH 
ZASTOSOWA�. W celu uzyskania bli�szych informacji - Powszechna 
Licencja Publiczna GNU. 
Z pewno�ci� wraz z niniejszym programem otrzyma�e� te� egzemplarz 
Powszechnej Licencji Publicznej GNU (GNU General Public License);
je�li nie - napisz do Free Software Foundation, Inc., 675 Mass Ave,
Cambridge, MA 02139, USA.

Pozdrawiam, konserw.
konserw@gmail.com
*/

#include <fstream>
#include <iostream>
#include <string>
#include <cstdio>
#include <vector>

bool linia (std::string sciezka, std::string tekst, unsigned n_linii){
	unsigned __int64 nolines=0;
	//------utworzenie vectora i jego wyczyszczenie------
	std::vector<std::string> linia;
	linia.clear();
	//---------wczytanie linia po linii---------
	std::ifstream plik;
	plik.open(sciezka.c_str());
	if (plik.is_open() && plik.good()){
		std::string buff;
		while(!plik.eof()){
			getline(plik, buff);
			linia.push_back(buff);
		}
		std::cout<< "wczytano wszystkie: "<<linia.size()<<" linii pliku: "<<sciezka<<"\n";
		plik.close();
	}else{
		std::cout<<"wczytanie pliku nie powiodlo sie\n";
		plik.close();
		return false;
	};

	//----Zapis---------

	std::ofstream zplik;
	zplik.open(sciezka.c_str());	
	for (unsigned i=0; i<linia.size(); ++i){
		if(i==n_linii){
			zplik<<"\tyear="<<tekst<<std::endl;
		};
        if(i==linia.size()-1){
            zplik<<linia[i];
        };
        if(i!=n_linii && i!=(linia.size()-1)){
        //else{
			zplik<<linia[i]<<std::endl;
		};
	};
	zplik.close();
	return true;
};

int main(int argc, char *argv[])
{
	std::string sciezka, tekst;
	unsigned n_linii;
    sciezka="common\\defines.txt";//sciezka do pliku Was interesujacego
	std::cout<<"Witam w NoTimeLimitPatch dla In Nomine!\n"
 "Program rozpowszechniany na zasadach GNU GPL\n"
        "Zalecana jest gra na ustawieniach domyslnych!\n"
		"Oczywiscie mozna zmienic date startu i konca gry w pliku tekstowym,\n"
        "ale kto by o tym myslal? :P\n"
		"Ten programik zrobi to za ciebie! :D\n"
        "(O ile wrzuciles go do swojego katalogu z gra)\n"
		"Pozdrawiam, konserw\n"
		"nacisnij enter aby kontynuowac\n";
	getchar();

	std::cout<<"wpisz rok daty rozpoczecia i nacisnij enter\n";
	std::cin>>tekst;
	n_linii=2;						//nr. linii ktora chcecie zmienic
	n_linii--;

	if(linia(sciezka, tekst, n_linii)) std::cout<<"zapis sie powiodl\n";
	else std::cout<<"cos poszlo zle\n";

	std::cout<<"wpisz rok konca swiata :P i wcisnij enter\n";
	std::cin>>tekst;
	n_linii=8;						//nr. linii ktora chcecie zmienic
	n_linii--;

	if(linia(sciezka, tekst, n_linii)) std::cout<<"zapis sie powiodl\n";
	else std::cout<<"cos poszlo zle\n";

	std::cout<<"\n"	
		"dziekuje za skorzystanie z mojego programu :)\n"
		"pozdrawiam i zycze milej zabawy, konserw\n"
  "UWAGA! jezeli gra po takim przedluzeniu sie wysypuje gdy ktos osiaga max poziom technologii\n"
  "nalezy sciagnac z mojego repozytorium techowacz i zamienic oryginalne pliki technologii na te stworzone techowaczem.\n"
  "Adres repozytorium: http://konserw.ovh.org/rep.htm\n"
	"nacisnij enter aby zakonczyc dzialanie programu\n";
	getchar();
	return 0;

}


