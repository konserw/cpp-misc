/*
 * Program do tworzenia jednostek wojskowych
 * drugiej generacji :)
 * dla gry Europa Universalis 3 (In Nomine)
 *
 * Copyright (C) 2009 Kamil Strzempowicz
 * Niniejszy program jest wolnym oprogramowaniem; mo�esz go 
 * rozprowadza� dalej i/lub modyfikowa� na warunkach Powszechnej
 * Licencji Publicznej GNU, wydanej przez Fundacj� Wolnego
 * Oprogramowania - wed�ug wersji 2-giej tej Licencji lub kt�rej�
 * z p�niejszych wersji. 
 * Niniejszy program rozpowszechniany jest z nadziej�, i� b�dzie on 
 * u�yteczny - jednak BEZ JAKIEJKOLWIEK GWARANCJI, nawet domy�lnej 
 * gwarancji PRZYDATNO�CI HANDLOWEJ albo PRZYDATNO�CI DO OKRE�LONYCH 
 * ZASTOSOWA�. W celu uzyskania bli�szych informacji - Powszechna 
 * Licencja Publiczna GNU. 
 * Z pewno�ci� wraz z niniejszym programem otrzyma�e� te� egzemplarz 
 * Powszechnej Licencji Publicznej GNU (GNU General Public License);
 * je�li nie - napisz do Free Software Foundation, Inc., 675 Mass Ave,
 * Cambridge, MA 02139, USA.
 * 
 * Pozdrawiam, konserw.
 * konserw@gmail.com
 */
#include "stdafx.h"


int main()
{
	system("chcp 1250");

	std::string code, nazwa_pliku, eng, pol;
	char exit;

	std::cout<<"Witam w programie do tworzenia plik�w lokalizacyjnych!\n"
		"Podaj nazwe dla swojego pliku (bez rozszerzenia):\t";
	std::cin >> nazwa_pliku;
	nazwa_pliku += ".csv";
	std::fstream lokal(nazwa_pliku.c_str(), std::fstream::out | std::fstream::app);

	do{	
		std::cout << "Podaj kod opisu:\t";
		std::cin.ignore();
		//std::cin >> code;
		std::getline(std::cin, code);
		std::cout<<"Podaj polsk� lokalizacj�:\n";
		//std::cin.ignore();
		std::getline(std::cin, pol);
		std::cout << "Podaj angielsk� lokalizacj�:\n";
		std::getline(std::cin, eng);
		
		lokal << code << ";" << eng << ";;;" << pol << ";;;;;;;;;x" << std::endl;
	
		std::cout<< "Kontynuowa� operacje na tym samym pliku?\t";
		std::cin>>exit;
		std::cout<<"\n=============================================================================\n";
	}while(exit != 'N' && exit != 'n');
	lokal.close();
	return 0;
}

