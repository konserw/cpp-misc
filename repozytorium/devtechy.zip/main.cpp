/*
techowacz - program do dorabiania poziom�w technologii w EU3:IN
Copyright (C) 2009 Kamil Strzempowicz
Niniejszy program jest wolnym oprogramowaniem; mo�esz go 
rozprowadza� dalej i/lub modyfikowa� na warunkach Powszechnej
Licencji Publicznej GNU, wydanej przez Fundacj� Wolnego
Oprogramowania - wed�ug wersji 2-giej tej Licencji lub kt�rej�
z p�niejszych wersji. 
Niniejszy program rozpowszechniany jest z nadziej�, i� b�dzie on 
u�yteczny - jednak BEZ JAKIEJKOLWIEK GWARANCJI, nawet domy�lnej 
gwarancji PRZYDATNO�CI HANDLOWEJ albo PRZYDATNO�CI DO OKRE�LONYCH 
ZASTOSOWA�. W celu uzyskania bli�szych informacji - Powszechna 
Licencja Publiczna GNU. 
Z pewno�ci� wraz z niniejszym programem otrzyma�e� te� egzemplarz 
Powszechnej Licencji Publicznej GNU (GNU General Public License);
je�li nie - napisz do Free Software Foundation, Inc., 675 Mass Ave,
Cambridge, MA 02139, USA.

Pozdrawiam, konserw.
konserw@gmail.com
*/


#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>

using std::cout;

int main(){

	const long zadana = 200; // <--- tu si� zmienia ile linii ma wyprodukowa� plik

	std::vector<std::string> pliki;
	std::string buff;
	std::vector<std::string> linie;

	cout<<"Witaj w programie robiacym dla ciebie nowe poziomy technologii do EU3: IN\n"
		"Program rozpowszechaniany na zasadach GNU GPL, licencja znajduje sie w katalogu release\n"
		"Copyleft konserw\n"
		"UWAGA! ten program nalezy uruchomic tylko jezeli znajduje sie w folderze glownym gry! ew. folderze glownym moda\n"
		"Nacisnij enter aby kontynuowac\n";
	std::cin.ignore();
	std::cin.get();


	const std::string path = "..\\common\\technologies";

	pliki.push_back(path + "\\government.txt");
	pliki.push_back(path + "\\land.txt");
	pliki.push_back(path + "\\naval.txt");
	pliki.push_back(path + "\\production.txt");
	pliki.push_back(path + "\\trade.txt");
	
	for(int i = 0; i < 5; ++i){	
		linie.clear();
		std::ifstream wczyt;

		wczyt.open(pliki[i].c_str());
		if(wczyt.good()){
			unsigned kupa = 0;
			while(getline(wczyt, buff).good()){
				linie.push_back(buff);
				++kupa;
				if(kupa == 73) break;
			}

			wczyt.close();
		cout<<"wczytanie do pamieci >starych< linii powiodlo sie\n";

		if (linie.size() >= zadana){
			std::cout << "Po co ci chlopie wiecej niz "<<zadana<<" poziomow technologii?!\n";
			std::cin.ignore();
			std::cin.get();
			return 0;
		}
		}
		else{
			cout<<"Operacja na pliku nie powiodla sie. Nastapi zakonczenie programu\n";
			wczyt.close();
			system("pause");
			return 0;
		}

		std::ofstream bak;
		std::string cos = pliki[i];
		cos += ".bak";
		bak.open(cos.c_str());
		for(unsigned j = 0; j < linie.size(); ++j) bak << linie[j] << std::endl;
		bak.close();
		cout << "backup zapisany poprawnie\n";

		unsigned bylo = linie.size();
		
		for(unsigned j = bylo; j < zadana; ++j){
			std::stringstream out;
			std::stringstream out2;
			std::stringstream out3;
			std::stringstream out4;
			
			buff.clear();
			buff = "technology = { id = ";
			out << j;
			buff += out.str();
			buff += "\taverage_year = ";
			out2 << 1890 + (10 * (j - 72));
			buff += out2.str();
			if(i != 0) buff += "\t";
			if(i == 1){//land
				buff += "supply_limit = ";
				out3 << 3.25 + (0.05 * (j - 72));
				buff += out3.str();
				buff += "\tland_morale = 4.0\t"
					"infantry_fire = 2.75\t"
					"cavalry_fire = 0.6\t"
					"artillery_fire = ";
				out4 << 8.8 + (0.1 * (j - 72));
				buff += out4.str();
				buff += "\tinfantry_shock = 2\t"
					"cavalry_shock = 4.5\t"
					"artillery_shock = 1.2";
			}
			else if(i == 2){//naval
				buff += "range = ";
				out3 << 850 + (10 * (j - 72));
				buff += out3.str();
				buff += "\tnaval_morale = 4.0\t"
					"bigship_fire = 3.0\t"
					"lightship_fire = 3.0\t"
					"galley_fire = 0.5\t"
					"transport_fire = 2.7\t"
					"bigship_shock = 2.9\t"
					"lightship_shock = 2.3\t"
					"galley_shock = 1.7\t"
					"transport_shock = 2.3";
			}
			else if(i == 3){//produkcja
				buff += "production_efficiency = ";
				out3 << 1.05 + ((j - 72) * 0.01);
				buff += out3.str();
			}
			else if(i == 4){//trade
				buff += "trade_efficiency = ";
					out3 << 1.05 + ((j - 72) * 0.01);
				buff += out3.str();
			}
			buff += "\t}";
			linie.push_back(buff);
		}
		cout<<"Dodano dodatkowe linie w pamieci\n";

		std::ofstream plik;
		plik.open(pliki[i].c_str());
		if(plik.good()){
			for(unsigned j=0; j<linie.size(); ++j)
				plik<<linie.at(j)<<std::endl;
			plik.close();
			cout<<"zapis pliku "<<pliki.at(i)<<" powiodl sie\n";
		}else{
			cout<<"Operacja na pliku nie powiodla sie. Nastapi zakonczenie programu\n";
			system("pause");
			return 0;
		}

	}
	cout<<"Prawdopodobnie wszystko poszlo w porzadku i mozesz grac :)\n";
	system("pause");

	return 0;
}
