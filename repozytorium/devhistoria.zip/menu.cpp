/*
 * historia - program do grzebania w plikach historii EU3
 * Copyright (C) 2009 Kamil Strzempowicz
 * Niniejszy program jest wolnym oprogramowaniem; mo�esz go 
 * rozprowadza� dalej i/lub modyfikowa� na warunkach Powszechnej
 * Licencji Publicznej GNU, wydanej przez Fundacj� Wolnego
 * Oprogramowania - wed�ug wersji 2-giej tej Licencji lub kt�rej�
 * z p�niejszych wersji. 
 * Niniejszy program rozpowszechniany jest z nadziej�, i� b�dzie on 
 * u�yteczny - jednak BEZ JAKIEJKOLWIEK GWARANCJI, nawet domy�lnej 
 * gwarancji PRZYDATNO�CI HANDLOWEJ albo PRZYDATNO�CI DO OKRE�LONYCH 
 * ZASTOSOWA�. W celu uzyskania bli�szych informacji - Powszechna 
 * Licencja Publiczna GNU. 
 * Z pewno�ci� wraz z niniejszym programem otrzyma�e� te� egzemplarz 
 * Powszechnej Licencji Publicznej GNU (GNU General Public License);
 * je�li nie - napisz do Free Software Foundation, Inc., 675 Mass Ave,
 * Cambridge, MA 02139, USA.
 * 
 * Pozdrawiam, konserw.
 * konserw@gmail.com
 */

#include "stdafx.h"
#include "menu.h"

unsigned short cMenu::wybor(unsigned y, unsigned x){

	max_wybor = vOpcje.size()-1;
	ktory = 0;
	char znak;

	for(;;){
		wclear(wOkno);
		wborder(wOkno, '|', '|', '-', '-', '+', '+', '+', '+');

		if(bWstep == false){
			for(unsigned i = 0; i < vOpcje.size(); ++i) mvwprintw(wOkno, y+i, x, "%s", vOpcje[i].c_str()); 
			mvprintw(y+ktory, x-2, "=>");
		}
		else{
			short ny = y + vWstep.size() +1;
			for(unsigned short i=0; i < vWstep.size(); ++i) mvwprintw(wOkno, y+i, x, "%s", vWstep[i].c_str()); 
			for(unsigned short i = 0; i < vOpcje.size(); ++i) mvwprintw(wOkno, ny+i, x, "%s", vOpcje[i].c_str()); 
			mvprintw(ny + ktory, x-2, "=>");
		}

		wrefresh(wOkno); 
        znak = getch();
		if (znak == 3 && ktory != min_wybor) ktory--;
		else if(znak == 2 && ktory != max_wybor) ktory++;
		else if(znak ==2 && ktory == max_wybor) ktory = min_wybor;
		else if(znak ==3 && ktory == min_wybor) ktory = max_wybor; 
		else if(znak == 13){
			log("wybor", "Wybrano", vOpcje[ktory].c_str());
			return ktory;
		}
	}
}

void log(){//wywolaj na poczatku programu aby wyczyscic log
	std::ofstream cerr("error.log", std::fstream::trunc);
	cerr << "czas\tfunkcja\tdzia�anie" << std::endl;
	cerr.close();
}
void log(const char* fun, const char* info){
	std::ofstream cerr("error.log", std::fstream::app);
	cerr << clock() / CLOCKS_PER_SEC << ":\t/" << fun << "/\t" << info << std::endl;
	cerr.close();
}
void log(const char* fun, const char* info, double liczba){
	std::ofstream cerr("error.log", std::fstream::app);
	cerr << clock() / CLOCKS_PER_SEC << ":\t/" << fun << "/\t" << info << ":\t" << liczba << std::endl;
	cerr.close();
}
void log(const char* fun, const char* info, const char* string){
	std::ofstream cerr("error.log", std::fstream::app);
	cerr << clock() / CLOCKS_PER_SEC << ":\t/" << fun << "/\t" << info << ":\t" << string << std::endl;
	cerr.close();
}

void loading(){
	clear();
	border('|', '|', '-', '-', '+', '+', '+', '+');
	mvprintw(10, 10, "Wczytywanie, prosze czekac...");
	refresh();
}