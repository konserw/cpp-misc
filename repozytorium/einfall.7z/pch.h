#pragma once

#include <ctime>
#include <windows.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>