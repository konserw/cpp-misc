//#include <iostream>
#include <curses.h>
//#include <cstdlib>
#include <vector>

#define _USE_MATH_DEFINES
#include <cmath>

