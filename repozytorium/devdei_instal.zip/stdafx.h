
#pragma once
#include <iostream>
#include <windows.h>
#include <fstream>
#include <string>
#include <vector>
#include <wininet.h>